import SwiftUI

struct LandingView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 50) {
                VStack(spacing: 10) {
                    Image("comparenion-icon")
                        .resizable() .scaledToFit() 
                        .frame(width: 300, height: 300) 
                    
                    Text("COMPARENION")
                        .font(.system(size: 32, weight: .bold))
                }
                .padding(.top, 50)
                

                VStack(spacing: 12) {
                    NavigationButton(icon: "dollarsign.circle", text: "value", destination: ValueView())
                    NavigationButton(icon: "flame.fill", text: "calories", destination: CalorieView())
                    NavigationButton(icon: "cube.fill", text: "sugar/sodium", destination: SugarSodiumView())
                    NavigationButton(icon: "fish.fill", text: "protein", destination: ProteinView())
                    NavigationButton(icon: "bolt.fill", text: "caffeine", destination: CaffeineView())
                }
                .padding(.horizontal)
                .padding(.bottom, 50)
            }
        }
    }
}

struct NavigationButton<Destination: View>: View {
    let icon: String
    let text: String
    let destination: Destination
    
    var body: some View {
        NavigationLink(destination: destination) {
            HStack {
                Spacer()
                Image(systemName: icon)
                    .foregroundColor(.black)
                Text(text)
                    .foregroundColor(.black)
                    .font(.system(size: 20))
                Spacer()
            }
            .padding()
            .frame(maxWidth: 210)
            .background(Color.yellow.opacity(0.5))
            .cornerRadius(10)
        }
        .buttonStyle(PlainButtonStyle()) 
    }
}

struct LandingView_Previews: PreviewProvider {
    static var previews: some View {
        LandingView()
    }
}

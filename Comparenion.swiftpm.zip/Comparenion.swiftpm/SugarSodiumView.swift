import SwiftUI

struct SugarSodiumView: View {
    @State private var productName: String = ""
    @State private var serving: Double = 0.0
    @State private var value: Double = 0.0
    @State private var isWeight: Bool = true 
    @State private var isSugar: Bool = true
    @State private var unitToggle: Int = 0
    
    @State private var comparisonItems: [Product] = loadComparisonItems(for: "sugar") 
    
    @State private var showResetAlert: Bool = false
    @State private var newIsSugar: Bool = true
    @State private var prevIsSugar: Bool = true
    @State private var isResettingOption: Bool = false
    
    @State private var showZeroAlert: Bool = false
    
    var body: some View {
        VStack {
            Spacer() 
            
            VStack(spacing: 20) {
                Image(systemName: "cube.fill")
                    .foregroundColor(.black)
                    .font(.system(size: 80)) 
                
                VStack {
                    Text("Sugar/Sodium")
                        .font(.largeTitle)
                        .bold()
                        .padding(.bottom, 25)
                    Text(isSugar ? "Least sugar per serving" : "Least sodium per serving")
                        .font(.title2)
                    
                }
                .padding(.bottom, 10)
                
                Picker("", selection: $isSugar) {
                    Text("Sugar").tag(true)
                    Text("Sodium").tag(false)
                }
                .pickerStyle(SegmentedPickerStyle())
                .frame(width: 200).padding(.bottom, 25)
                .onChange(of: isSugar) { oldValue, newValue in
                    
                    if isResettingOption {
                        isResettingOption = false
                        return
                    }
                    if !comparisonItems.isEmpty {
                        prevIsSugar = oldValue
                        newIsSugar = newValue
                        showResetAlert = true
                    }
                }
                
                VStack(spacing: 20) {
                    InputRow(label: "Name:", content: {
                        TextField("Enter name", text: $productName).frame(width: 200)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    })
                    InputRow(label: isSugar ? "Sugar per serving:" : "Sodium per serving", content: {
                        HStack {
                            TextField("0", value: $value, formatter: numberFormatter)
                                .keyboardType(.decimalPad)
                                .frame(width: 100)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .pickerStyle(SegmentedPickerStyle())
                            Text(isSugar ? "g" : "mg")
                        }
                    })
                    InputRow(label: "Serving size:", content: {
                        HStack {
                            TextField("0.00", value: $serving, formatter: numberFormatter)
                                .keyboardType(.decimalPad)
                                .frame(width: 100)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            Picker("", selection: $unitToggle) {
                                if isWeight {
                                    Text("g").tag(0)
                                    Text("lb").tag(1)
                                    Text("oz").tag(2)
                                } else {
                                    Text("ml").tag(0)
                                    Text("oz").tag(1)
                                }
                            }
                            .pickerStyle(SegmentedPickerStyle())
                            .frame(width: 150)
                        }
                    })
                    
                    
                }
                
                Button(action: addToComparison) {
                    Text("+ Add to Comparison")
                        .foregroundColor(.black)
                        .frame(maxWidth: 200)
                        .padding()
                        .background(Color.yellow.opacity(0.7))
                        .cornerRadius(10)
                }
                .padding(.top, 20)
            }
            .padding()
            .frame(maxWidth: 350) 
            
            Spacer()
        }
        .navigationTitle("Sugar Sodium")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                HStack {
                    Text(isWeight ? "Weight" : "Volume")
                        .font(.subheadline)
                        .foregroundColor(.black)
                    Toggle("", isOn: $isWeight)
                        .toggleStyle(SwitchToggleStyle())
                        .labelsHidden() 
                }
                .padding(.trailing, 8)
                .padding(.top, 40)
            }
            ToolbarItem(placement: .navigationBarTrailing){
                NavigationLink(destination: ComparisonView(comparisonItems: $comparisonItems, viewID: "sugar")) {
                    ZStack{
                        Image("comparison-empty").resizable().scaledToFit().frame(width: 70, height: 50).padding(.top, 30)
                        
                        if comparisonItems.count > 0 {
                            Image("comparison").resizable().scaledToFit().frame(width: 70, height: 50).padding(.top, 30)
                            Text("\(comparisonItems.count)")
                                .font(.caption2)
                                .bold()
                                .foregroundColor(.white)
                                .frame(width: 23, height: 23)
                                .background(Color.purple)
                                .clipShape(Circle())
                                .offset(x: -18, y: 1)
                        }
                    }
                }
            }
        }
        .alert("Reset Comparison List", isPresented: $showResetAlert) {
            Button("Yes", role: .destructive) {
                comparisonItems.removeAll()
                saveComparisonItems(comparisonItems, for: "sugar")
                isSugar = newIsSugar
            }
            Button("No", role: .cancel) {
                isResettingOption = true
                isSugar = prevIsSugar
            }
        } message: {
            Text("Switching comparison type will clear the comparison list. Are you sure you want to continue?")
        }
        .alert("Serving size is zero", isPresented: $showZeroAlert) {
            Button("Okay", role: .cancel) {
                showZeroAlert = false
            }
            .padding()
        } message: {
            Text("The serving size must be greater than zero for comparison.")
        }
    }
    
    func addToComparison() {
        if(serving == 0.0){
            showZeroAlert = true
            return
        }
        let standardizedVal =  Utilities.standardizeVal(val: value, isWeight: isWeight, unitToggle: unitToggle)
        let standardizedServing =  Utilities.standardizeVal(val: serving, isWeight: isWeight, unitToggle: unitToggle)
        let compVal = standardizedVal/standardizedServing
        var unit = ""
        var title = ""
        if (isSugar){
            unit = "g of sugar per serving"
            title = "Least sugar per serving"
        } else {
            unit = "mg of sodium per g serving"
            title = "Least sodium per serving"
        }
        
        let newProduct = Product(name: productName, value: compVal, unit: unit, order: "asc", title: title)
        comparisonItems.append(newProduct)
        saveComparisonItems(comparisonItems,for: "sugar")
        
        productName = ""
        serving = 0.0
        value = 0.0
    }
}

struct SugarSodiumView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            SugarSodiumView()
        }
    }
}

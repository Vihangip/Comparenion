import SwiftUI

struct ComparisonView: View {
    @Binding var comparisonItems: [Product]
     var viewID: String 
    
    var body: some View {
        VStack(spacing: 10) {
            if comparisonItems.isEmpty {
                Image("comparison-empty")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 150, height: 150)
            } else {
                Image("comparison")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 150, height: 150)
            }
            
            
            if let firstItem = comparisonItems.first {
                Text(firstItem.title)
                    .font(.system(size: 32, weight: .bold))
            } else {
                Text("Add products to see comparison")
                    .font(.system(size: 32, weight: .bold))
            }
        }
        .padding(.top, 50) .padding(.bottom, 50)
        VStack {
            if comparisonItems.isEmpty {
                Text("No items added")
                    .font(.title2)
                    .foregroundColor(.gray)
            } else {
                let sortedItems = comparisonItems.sorted {
                    ($0.order == "desc") ? ($0.value > $1.value) : ($0.value < $1.value)
                }
                    
                ScrollView {
                    VStack(spacing: 5) {
                        ForEach(Array(sortedItems.enumerated()), id: \.element.id) { index, item in
                            HStack{
                                Text(item.name)
                                    .font(.headline)
                                .frame(width: 100,alignment: .leading)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                Text(formatValue(item.value) + " \(item.unit)")
                                    .font(.body)
                                    .frame(width: 200, alignment: .trailing)
                            }
                            .padding()
                            .frame(width: 400,height: 75, alignment: .leading)
                            .background(calculateGreenShade(for: index, totalItems: sortedItems.count))
                            .cornerRadius(10)
                            .shadow(radius: 2) 
                            
                            Button(action: {
                                removeItem(item)
                            }) {
                                Image(systemName: "xmark.circle")
                                    .foregroundColor(.black)
                                    .font(.title2)
                            }
                            .offset(x: 230, y: -65)
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
            }
        }
        .navigationTitle("Comparison List")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Clear") {
                    comparisonItems.removeAll()
                    saveComparisonItems(comparisonItems, for: viewID)
                }
            }
        }
        .onAppear {
            comparisonItems = loadComparisonItems(for: viewID)
        }
        .onDisappear {
            saveComparisonItems(comparisonItems, for: viewID)
        }
    }
    func removeItem(_ item: Product) {
        comparisonItems.removeAll { $0.id == item.id }
        saveComparisonItems(comparisonItems, for: viewID)
    }
    
    func calculateGreenShade(for index: Int, totalItems: Int) -> Color {
        guard totalItems > 1 else {
            return Color(red: 44 / 255, green: 230 / 255, blue: 93 / 255)
        }
        
        let gradient = CGFloat(index) / CGFloat(totalItems - 1)
        
        let darkestRed: CGFloat = 44 / 255
        let darkestBlue: CGFloat = 93 / 255
        
        let lightestRed: CGFloat = 132 / 255
        let lightestBlue: CGFloat = 159 / 255
        
        let red = darkestRed + (lightestRed - darkestRed) * (gradient + 0.5)
        let blue = darkestBlue + (lightestBlue - darkestBlue) * (gradient + 0.5)
        
        let green: CGFloat = 230 / 255
        
        return Color(red: red, green: green, blue: blue)
    }


}

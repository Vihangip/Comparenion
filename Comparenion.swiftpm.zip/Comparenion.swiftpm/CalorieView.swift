import SwiftUI

struct CalorieView: View {
    @State private var productName: String = ""
    @State private var calories: Double = 0.0
    @State private var price: Double = 0.0
    @State private var serving: Double = 0.0
    @State private var totalWeight: Double = 0.0
    
    @State private var isWeight: Bool = true 
    @State private var servingUnitToggle: Int = 0
    @State private var totalUnitToggle: Int = 0
    
    @State private var comparisonItems: [Product] = loadComparisonItems(for: "calories") 
    
    @State private var minimum: Bool = true
    
    @State private var showResetAlert: Bool = false
    @State private var newMinimum: Bool = true
    @State private var prevMinimum: Bool = true
    @State private var isResettingOption: Bool = false
    
    @State private var showZeroAlert: Bool = false
    
    var body: some View {
        VStack {
            Spacer()
            
            VStack(spacing: 20) {
                Image(systemName: "flame.fill")
                    .foregroundColor(.black)
                    .font(.system(size: 80))
                
                VStack {
                    Text("Calories")
                        .font(.largeTitle)
                        .bold()
                    .padding(.bottom, 25)
                    HStack{
                        Menu {
                            Button(action: {  handleSelectionChange(newValue: true)}) {
                                Text("Minimum")
                                    .foregroundColor(.black)
                            }
                            Button(action: {  handleSelectionChange(newValue: false)}) {
                                    Text("Maximum")
                                        .foregroundColor(.black) 
                                }
                        } label: {
                            HStack {
                                Text(minimum ? "Minimum" : "Maximum") 
                                    .foregroundColor(.black) 
                                Image(systemName: "chevron.down")
                                    .foregroundColor(.black) 
                            }
                            .padding(5) 
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                        }
                        Text("calories for the")
                            .font(.title2)
                    }
                    Text("lowest price")
                        .font(.title2)
                    
                }
                .padding(.bottom, 10)
                
                VStack(spacing: 20) {
                    InputRow(label: "Name:", content: {
                        TextField("Enter name", text: $productName).frame(width: 200)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    })
                    InputRow(label: "Calories per serving:", content: {
                        HStack {
                            TextField("0", value: $calories, formatter: numberFormatter)
                                .keyboardType(.decimalPad)
                                .frame(width: 100)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .pickerStyle(SegmentedPickerStyle())
                            Text("cal")
                        }
                    })
                    InputRow(label: "Serving size:", content: {
                        HStack {
                            TextField("0", value: $serving, formatter: numberFormatter)
                                .keyboardType(.decimalPad)
                                .frame(width: 80)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            
                            Picker("", selection: $servingUnitToggle) {
                                if isWeight {
                                    Text("g").tag(0)
                                    Text("lb").tag(1)
                                    Text("oz").tag(2)
                                } else {
                                    Text("ml").tag(0)
                                    Text("oz").tag(1)
                                }
                            }
                            .pickerStyle(SegmentedPickerStyle())
                            .frame(width: 150)
                        }
                    })
                    
                    InputRow(label: "Total Product Size", content: {
                        HStack {
                            TextField("0.00", value: $totalWeight, formatter: numberFormatter)
                                .keyboardType(.decimalPad)
                                .frame(width: 100)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            Picker("", selection: $totalUnitToggle) {
                                if isWeight {
                                    Text("g").tag(0)
                                    Text("lb").tag(1)
                                    Text("oz").tag(2)
                                } else {
                                    Text("ml").tag(0)
                                    Text("oz").tag(1)
                                }
                            }
                            .pickerStyle(SegmentedPickerStyle())
                            .frame(width: 150) 
                        }
                    })
                    
                    InputRow(label: "Price:", content: {
                        HStack {
                            TextField("0.00", value: $price, formatter: numberFormatter)
                                .keyboardType(.decimalPad)
                                .frame(width: 100)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            Text("$")
                        }
                    })
                }
                
                Button(action: addToComparison) {
                    Text("+ Add to Comparison")
                        .foregroundColor(.black)
                        .frame(maxWidth: 200)
                        .padding()
                        .background(Color.yellow.opacity(0.7))
                        .cornerRadius(10)
                }
                .padding(.top, 20)
            }
            .padding()
            .frame(maxWidth: 350) 
            
            Spacer() 
        }
        .navigationTitle("Calories")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                HStack {
                    Text(isWeight ? "Weight" : "Volume")
                        .font(.subheadline)
                        .foregroundColor(.black)
                    Toggle("", isOn: $isWeight)
                        .toggleStyle(SwitchToggleStyle())
                        .labelsHidden() 
                }
                .padding(.trailing, 8)
                .padding(.top, 40)
            }
            ToolbarItem(placement: .navigationBarTrailing){
                NavigationLink(destination: ComparisonView(comparisonItems: $comparisonItems, viewID: "calories")) {
                    ZStack{
                        Image("comparison-empty").resizable().scaledToFit().frame(width: 70, height: 50).padding(.top, 30)
                        
                        if comparisonItems.count > 0 {
                            Image("comparison").resizable().scaledToFit().frame(width: 70, height: 50).padding(.top, 30)
                            Text("\(comparisonItems.count)")
                                .font(.caption2)
                                .bold()
                                .foregroundColor(.white)
                                .frame(width: 23, height: 23)
                                .background(Color.purple)
                                .clipShape(Circle())
                                .offset(x: -18, y: 1)
                        }
                    }
                }
            }
        }
        .alert("Reset Comparison List", isPresented: $showResetAlert) {
            Button("Yes", role: .destructive) {
                comparisonItems.removeAll()
                saveComparisonItems(comparisonItems, for: "calorie")
                minimum = newMinimum
            }
            Button("No", role: .cancel) {
                isResettingOption = true
                minimum = prevMinimum
            }
        } message: {
            Text("Switching comparison type will clear the comparison list. Are you sure you want to continue?")
        }
        .alert("Value is Zero", isPresented: $showZeroAlert) {
            Button("Okay", role: .cancel) {
                showZeroAlert = false
            }
            .padding()
        } message: {
            if(price == 0.0){
                Text("The price must be greater than zero for comparison.")
            } else if (serving == 0.0){
                Text("The serving size must be greater than zero for comparison.")
            }
        }
            
    }
    
    func handleSelectionChange(newValue: Bool) {
        if isResettingOption {
            isResettingOption = false
            return
        }
        
        if !comparisonItems.isEmpty {
            prevMinimum = minimum
            newMinimum = newValue
            showResetAlert = true
        } else {
            minimum = newValue
        }
    }
    
    func addToComparison() {
        if (price == 0.0 || serving == 0.0){
            showZeroAlert = true
            return
        }
        let standardizedServing = Utilities.standardizeVal(val: serving, isWeight: isWeight, unitToggle: servingUnitToggle)
        let standardizedTotal = Utilities.standardizeVal(val: totalWeight, isWeight: isWeight, unitToggle: totalUnitToggle)
        let absCalories = (calories / standardizedServing) * standardizedTotal
        let compVal = absCalories / price
        let order = minimum ? "asc" : "desc"
        let title = minimum ? "Least calories per dollar" : "Most calories per dollar"
        let newProduct = Product(name: productName, value: compVal, unit: "cal per $", order: order, title:title)
        comparisonItems.append(newProduct)
        saveComparisonItems(comparisonItems,for: "calories")
        
        productName = ""
        calories = 0.0
        serving = 0.0
        totalWeight = 0.0
        price = 0.0
    }
}

struct CalorieView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            CalorieView()
        }
    }
}

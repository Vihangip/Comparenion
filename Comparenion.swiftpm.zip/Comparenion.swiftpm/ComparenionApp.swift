import SwiftUI

@main
struct Comparenion: App {
    var body: some Scene {
        WindowGroup {
            LandingView()
        }
    }
}

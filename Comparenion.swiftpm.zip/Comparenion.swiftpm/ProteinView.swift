import SwiftUI

struct ProteinView: View {
    @State private var productName: String = ""
    @State private var measureVal: Double = 0.0
    
    @State private var isWeight: Bool = true 
    @State private var unit: String = "g per $"
    
    @State private var protein: Double = 0.0
    @State private var serving: Double = 0.0
    @State private var totalWeight: Double = 0.0
    @State private var lowOrHigh: String = "lowest"
    @State private var selectedOption: String = "Price" 
    
    @State private var servingUnitToggle: Int = 0
    @State private var totalUnitToggle: Int = 0
    
    @State private var comparisonItems: [Product] = loadComparisonItems(for: "protein") 
    
    @State private var showResetAlert: Bool = false
    @State private var newSelectedOption: String = ""
    @State private var prevSelectedOption: String = ""
    @State private var isResettingOption: Bool = false
    
    @State private var showZeroAlert: Bool = false
    
    var body: some View {
        VStack {
            Spacer() 
            
            VStack(spacing: 20) {
                Image("proteins")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 150, height: 150)
                
                VStack(spacing: 25) {
                    Text("Protein")
                        .font(.largeTitle)
                        .bold()
                    HStack {
                        Text("Most protein for the")
                            .font(.title2)
                        
                        Menu {
                            Button(action: { 
                                lowOrHigh = "lowest" 
                                 selectedOption = "Price"
                            }) {
                                Text("lowest")
                                    .foregroundColor(.black)
                            }
                            Button(action: { lowOrHigh = "highest" 
                                selectedOption = "ProteinDensity"}) {
                                Text("highest")
                                    .foregroundColor(.black) 
                            }
                        } label: {
                            HStack {
                                Text(lowOrHigh) 
                                    .foregroundColor(.black) 
                                Image(systemName: "chevron.down")
                                    .foregroundColor(.black) 
                            }
                            .padding(5) 
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                        }
                    }
          
                }
                .multilineTextAlignment(.center)
                
                Picker("", selection: $selectedOption) {
                    if lowOrHigh == "lowest" {
                        Text("Price").tag("Price")
                        Text("Calories").tag("LowCalories")
                        Text("Trans Fat").tag("TransFat")
                        Text("Sugar").tag("Sugar")
                        Text("Sodium").tag("Sodium")
                    } else {
                        Text("Protein density").tag("ProteinDensity")
                        Text("Calories").tag("HighCalories")
                        Text("Fiber").tag("Fiber")
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .frame(width: 400).padding(.bottom, 25)
                .onChange(of: selectedOption) { oldValue, newValue in
                    
                    if isResettingOption {
                        isResettingOption = false 
                        return
                    }
                    if !comparisonItems.isEmpty {
                        prevSelectedOption = oldValue
                        newSelectedOption = newValue
                        showResetAlert = true
                    } else {
                        updateUnit(for: newValue)
                    }
                }
                
                VStack(spacing: 20) {
                    InputRow(label: "Name:", content: {
                        TextField("Enter name", text: $productName).frame(width: 200)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    })
                    InputRow(label: "Protein per serving:", content: {
                        HStack {
                            TextField("0", value: $protein, formatter: numberFormatter)
                                .keyboardType(.decimalPad)
                                .frame(width: 100)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            .pickerStyle(SegmentedPickerStyle())
                            Text("g")
                        }
                    })
                    if(selectedOption == "Price" || selectedOption == "ProteinDensity"){
                        InputRow(label: "Serving size:", content: {
                            HStack {
                                TextField("0", value: $serving, formatter: numberFormatter)
                                    .keyboardType(.decimalPad)
                                    .frame(width: 100)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .pickerStyle(SegmentedPickerStyle())
                                
                                Picker("", selection: $servingUnitToggle) {
                                    if isWeight {
                                        Text("g").tag(0)
                                        Text("lb").tag(1)
                                        Text("oz").tag(2)
                                    } else {
                                        Text("ml").tag(0)
                                        Text("oz").tag(1)
                                    }
                                }
                                .pickerStyle(SegmentedPickerStyle())
                                .frame(width: 150)
                            }
                        })
                        
                    }
                    
                    if selectedOption == "Price" {
                        InputRow(label: "Total Product Size", content: {
                            HStack {
                                TextField("0.00", value: $totalWeight, formatter: numberFormatter)
                                    .keyboardType(.decimalPad)
                                    .frame(width: 100)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                Picker("", selection: $totalUnitToggle) {
                                    if isWeight {
                                        Text("g").tag(0)
                                        Text("lb").tag(1)
                                        Text("oz").tag(2)
                                    } else {
                                        Text("ml").tag(0)
                                        Text("oz").tag(1)
                                    }
                                }
                                .pickerStyle(SegmentedPickerStyle())
                                .frame(width: 150)
                            }
                        })
                    }
                    
                    if selectedOption != "ProteinDensity" {
                        InputRow(label: selectedOptionLabel, content: {
                            HStack {
                                TextField("0.00", value: $measureVal, formatter: numberFormatter)
                                    .keyboardType(.decimalPad)
                                    .frame(width: 100)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                Text(selectedOptionUnit)
                            }
                        })
                    }
                }
                
                Button(action: addToComparison) {
                    Text("+ Add to Comparison")
                        .foregroundColor(.black)
                        .frame(maxWidth: 200)
                        .padding()
                        .background(Color.yellow.opacity(0.7))
                        .cornerRadius(10)
                }
                .padding(.top, 20)
            }
            .padding()
            .frame(maxWidth: 350)
            
            Spacer()
        }
        .navigationTitle("Protein")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                HStack {
                    Text(isWeight ? "Weight" : "Volume")
                        .font(.subheadline)
                        .foregroundColor(.black)
                    Toggle("", isOn: $isWeight)
                        .toggleStyle(SwitchToggleStyle())
                        .labelsHidden() 
                }
                .padding(.trailing, 8)
                .padding(.top, 40)
            }
            ToolbarItem(placement: .navigationBarTrailing){
                NavigationLink(destination: ComparisonView(comparisonItems: $comparisonItems, viewID: "protein")) {
                    ZStack{
                        Image("comparison-empty").resizable().scaledToFit().frame(width: 70, height: 50).padding(.top, 30)
                        
                        if comparisonItems.count > 0 {
                            Image("comparison").resizable().scaledToFit().frame(width: 70, height: 50).padding(.top, 30)
                            Text("\(comparisonItems.count)")
                                .font(.caption2)
                                .bold()
                                .foregroundColor(.white)
                                .frame(width: 23, height: 23)
                                .background(Color.purple)
                                .clipShape(Circle())
                                .offset(x: -18, y: 1)
                        }
                    }
                }
            }
        }
        .alert("Reset Comparison List", isPresented: $showResetAlert) {
            Button("Yes", role: .destructive) {
                comparisonItems.removeAll()
                saveComparisonItems(comparisonItems, for: "protein")
                selectedOption = newSelectedOption
                updateUnit(for: newSelectedOption)
            }
            Button("No", role: .cancel) {
                isResettingOption = true
                selectedOption = prevSelectedOption
                updateUnit(for: prevSelectedOption)
            }
        } message: {
            Text("Switching comparison type will clear the comparison list. Are you sure you want to continue?")
        }
        .alert("Value is zero", isPresented: $showZeroAlert) {
            Button("Okay", role: .cancel) {
                showZeroAlert = false
            }
            .padding()
        } message: {
            Text("All values must be greater than zero for comparison.")
        }
    }
    
    var selectedOptionLabel: String {
        switch selectedOption {
        case "Price": return "Price:"
        case "LowCalories": return "Calories per serving:"
        case "TransFat": return "Trans Fat per serving:"
        case "Sugar": return "Sugar per serving:"
        case "Sodium": return "Sodium per serving:"
        case "ProteinDensity": return "Protein density:"
        case "HighCalories": return "Calories per serving:"
        case "Fiber": return "Fiber per serving:"
        default: return ""
        }
    }
    
    var selectedOptionUnit: String {
        switch selectedOption {
        case "Price": return "$"
        case "LowCalories": return "cal"
        case "TransFat": return "g"
        case "Sugar": return "g"
        case "Sodium": return "mg"
        case "ProteinDensity": return "g"
        case "HighCalories": return "cal"
        case "Fiber": return "g"
        default: return ""
        }
    }
    
    var title: String {
        switch selectedOption {
        case "Price": return "Most protein for the lowest price"
        case "LowCalories": return "Most protein for the least calories"
        case "TransFat": return "Most protein for the least trans fat"
        case "Sugar": return "Most protein for the lowest sugar"
        case "Sodium": return "Most protein for the lowest sodium"
        case "ProteinDensity": return "Highest protein density"
        case "HighCalories": return "Most protein for the most calories"
        case "Fiber": return "Most protein for the most fiber"
        default: return ""
        }
    }
    
    func updateUnit(for option: String) {
        switch option {
        case "Price": unit = "g of protein per $"
        case "LowCalories": unit = "g of protein per cal"
        case "TransFat": unit = "g of protein per gram of trans fat"
        case "Sugar": unit = "g of protein per gram of sugar"
        case "Sodium": unit = "g of protein per mg of sodium"
        case "ProteinDensity": unit = "g of protein per 100g"
        case "HighCalories": unit = "g of protein per cal"
        case "Fiber": unit = "g of protein per gram of fiber"
        default: unit = "g of protein per $"
        }
    }
    
    func calcProtein(protein: Double, serving: Double, total: Bool) -> Double{
        if(total){
            let standardizedTotal = Utilities.standardizeVal(val: totalWeight, isWeight: isWeight, unitToggle: totalUnitToggle)
            return (protein/serving) * standardizedTotal
        }
        return (protein/serving) * 100
    }

    
    func addToComparison() {
        if((selectedOption != "ProteinDensity" && measureVal == 0.0 ) || protein == 0.0){
            showZeroAlert = true
            return
        } else if (selectedOption == "Price" && (serving == 0.0 || totalWeight == 0.0)){
            showZeroAlert = true
            return
        } else if (selectedOption == "ProteinDensity" && serving == 0.0){
            showZeroAlert = true
            return
        } 
        
        let standardizedServing = Utilities.standardizeVal(val: serving, isWeight: isWeight, unitToggle: servingUnitToggle)
        var compVal: Double = 0.0 
        if (selectedOption == "ProteinDensity"){
            compVal = calcProtein(protein: protein, serving: standardizedServing, total: false)
        } else if (selectedOption == "Price") {
            let totalProtein = calcProtein(protein: protein, serving: standardizedServing, total: true)
            compVal = totalProtein/measureVal
        } else {
            compVal = protein/measureVal
        }
        let newProduct = Product(name: productName, value: compVal, unit: unit, order: "desc", title: title)
        comparisonItems.append(newProduct)
        saveComparisonItems(comparisonItems, for: "protein")
        
        productName = ""
        protein = 0.0
        serving = 0.0
        measureVal = 0.0
        totalWeight = 0.0

    }
}

struct ProteinView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ProteinView()
        }
    }
}

import SwiftUI

struct ValueView: View {
    @State private var productName: String = ""
    @State private var weightOrVolume: Double = 0.0
    @State private var price: Double = 0.0
    
    @State private var isWeight: Bool = true 
    @State private var unitToggle: Int = 0
    
    @State private var comparisonItems: [Product] = loadComparisonItems(for: "value")
    
    @State private var showZeroAlert: Bool = false
    
    var body: some View {
        VStack {
            Spacer()
            
            VStack(spacing: 20) {
                Image(systemName: "dollarsign.circle.fill")
                    .foregroundColor(.black)
                    .font(.system(size: 80))
                
                VStack(spacing: 25) {
                    Text("Value")
                        .font(.largeTitle)
                        .bold()
                    
                    Text("Most product for the lowest price")
                        .font(.title2)
                }
                .multilineTextAlignment(.center)
                .padding(.bottom, 25)
                
                VStack(spacing: 20) {
                    InputRow(label: "Name:", content: {
                        TextField("Enter name", text: $productName).frame(width: 200)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    })
                    InputRow(label: isWeight ? "Weight:" : "Volume:", content: {
                        HStack {
                            TextField("0", value: $weightOrVolume, formatter: numberFormatter)
                                .keyboardType(.decimalPad)
                                .frame(width: 80)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            
                            Picker("", selection: $unitToggle) {
                                if isWeight {
                                    Text("g").tag(0)
                                    Text("lb").tag(1)
                                    Text("oz").tag(2)
                                } else {
                                    Text("ml").tag(0)
                                    Text("oz").tag(1)
                                }
                            }
                            .pickerStyle(SegmentedPickerStyle())
                            .frame(width: 150) 
                        }
                    })
                    
                    InputRow(label: "Price:", content: {
                        HStack {
                            TextField("0.00", value: $price, formatter: numberFormatter)
                                .keyboardType(.decimalPad)
                                .frame(width: 100)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            Text("$")
                        }
                    })
                }
                
                Button(action: addToComparison) {
                    Text("+ Add to Comparison")
                        .foregroundColor(.black)
                        .frame(maxWidth: 200)
                        .padding()
                        .background(Color.yellow.opacity(0.7))
                        .cornerRadius(10)
                }
                .padding(.top, 20)
            }
            .padding()
            .frame(maxWidth: 350) 
            
            Spacer() 
        }
        .navigationTitle("Value")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                HStack {
                    Text(isWeight ? "Weight" : "Volume")
                        .font(.subheadline)
                        .foregroundColor(.black)
                    Toggle("", isOn: $isWeight)
                        .toggleStyle(SwitchToggleStyle())
                        .labelsHidden() 
                }
                .padding(.trailing, 8)
                .padding(.top, 40)
            }
            ToolbarItem(placement: .navigationBarTrailing){
                NavigationLink(destination: ComparisonView(comparisonItems: $comparisonItems, viewID: "value")) {
                    ZStack{
                        Image("comparison-empty").resizable().scaledToFit().frame(width: 70, height: 50).padding(.top, 30)
                        
                        if comparisonItems.count > 0 {
                            Image("comparison").resizable().scaledToFit().frame(width: 70, height: 50).padding(.top, 30)
                            Text("\(comparisonItems.count)")
                                .font(.caption2)
                                .bold()
                                .foregroundColor(.white)
                                .frame(width: 23, height: 23)
                                .background(Color.purple)
                                .clipShape(Circle())
                                .offset(x: -18, y: 1)
                        }
                    }
                }
            }
        }
        .alert("Price is zero", isPresented: $showZeroAlert) {
            Button("Okay", role: .cancel) {
                showZeroAlert = false
            }
            .padding()
        } message: {
            Text("Price must be greater than zero for comparison.")
        }
    }
    
    func addToComparison() {
        if(price == 0.0){
            showZeroAlert = true
            return
        }
        let standardizedVal = Utilities.standardizeVal(val: weightOrVolume, isWeight: isWeight, unitToggle: unitToggle)
        let compVal = standardizedVal / price
        let unit = isWeight ? "g per $" : "ml per $"
        let newProduct = Product(name: productName, value: compVal, unit: unit, order: "desc", title:"Most product for the lowest price")
        comparisonItems.append(newProduct)
        saveComparisonItems(comparisonItems,for: "value")
        
        productName = ""
        weightOrVolume = 0.0
        price = 0.0
    }
}

struct ValueView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ValueView()
        }
    }
}

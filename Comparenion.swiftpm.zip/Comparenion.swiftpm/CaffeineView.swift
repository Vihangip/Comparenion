import SwiftUI

struct CaffeineView: View {
    @State private var productName: String = ""
    @State private var caffeine: Double = 0.0
    @State private var value: Double = 0.0
    
    @State private var selectedOption: String = "Price" 
    @State private var unitToggle: Int = 0
    
    @State private var comparisonItems: [Product] = loadComparisonItems(for: "caffeine") 
    
    @State private var showResetAlert: Bool = false
    @State private var newSelectedOption: String = ""
    @State private var prevSelectedOption: String = ""
    @State private var isResettingOption: Bool = false
    
    @State private var showZeroAlert: Bool = false
    var body: some View {
        VStack {
            Spacer()
            
            VStack(spacing: 20) {
                Image(systemName: "bolt.fill")
                    .foregroundColor(.black)
                    .font(.system(size: 80))
                
                VStack {
                    Text("Caffeine")
                        .font(.largeTitle)
                        .bold()
                        .padding(.bottom, 25)
                    Text("Most caffeine for the lowest")
                        .font(.title2)
                    
                }
                .padding(.bottom, 10)
                
                Picker("", selection: $selectedOption) {
                    Text("Price").tag("Price")
                    Text("Sugar").tag("Sugar")
                    Text("Calories").tag("Calories")
                }
                .pickerStyle(SegmentedPickerStyle())
                .frame(width: 300).padding(.bottom, 25)
                .onChange(of: selectedOption) { oldValue, newValue in
                    
                    if isResettingOption {
                        isResettingOption = false 
                        return
                    }
                    if !comparisonItems.isEmpty {
                        prevSelectedOption = oldValue
                        newSelectedOption = newValue
                        showResetAlert = true
                    }
                }
                
                VStack(spacing: 20) {
                    InputRow(label: "Name:", content: {
                        TextField("Enter name", text: $productName).frame(width: 200)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    })
                    InputRow(label: "Caffeine per serving:", content: {
                        HStack {
                            TextField("0", value: $caffeine, formatter: numberFormatter)
                                .keyboardType(.decimalPad)
                                .frame(width: 100)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .pickerStyle(SegmentedPickerStyle())
                            Text("mg")
                        }
                    })
                    if (selectedOption == "Price") {
                        InputRow(label: "Price:", content: {
                            HStack {
                                TextField("0.00", value: $value, formatter: numberFormatter)
                                    .keyboardType(.decimalPad)
                                    .frame(width: 100)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                Text("$")
                            }
                        })
                    } else if (selectedOption == "Sugar"){
                        InputRow(label: "Sugar per serving:", content: {
                            HStack {
                                TextField("0.00", value: $value, formatter: numberFormatter)
                                    .keyboardType(.decimalPad)
                                    .frame(width: 100)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                Text("g")
                            }
                        })
                    } else {
                        InputRow(label: "Calories per serving:", content: {
                            HStack {
                                TextField("0.00", value: $value, formatter: numberFormatter)
                                    .keyboardType(.decimalPad)
                                    .frame(width: 100)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                Text("cal")
                            }
                        })
                    }
                    
                }
                
                Button(action: addToComparison) {
                    Text("+ Add to Comparison")
                        .foregroundColor(.black)
                        .frame(maxWidth: 200)
                        .padding()
                        .background(Color.yellow.opacity(0.7))
                        .cornerRadius(10)
                }
                .padding(.top, 20)
            }
            .padding()
            .frame(maxWidth: 350)
            
            Spacer()
        }
        .navigationTitle("Caffeine")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing){
                NavigationLink(destination: ComparisonView(comparisonItems: $comparisonItems, viewID: "caffeine")) {
                    ZStack{
                        Image("comparison-empty").resizable().scaledToFit().frame(width: 70, height: 50).padding(.top, 30)
                        
                        if comparisonItems.count > 0 {
                            Image("comparison").resizable().scaledToFit().frame(width: 70, height: 50).padding(.top, 30)
                            Text("\(comparisonItems.count)")
                                .font(.caption2)
                                .bold()
                                .foregroundColor(.white)
                                .frame(width: 23, height: 23)
                                .background(Color.purple)
                                .clipShape(Circle())
                                .offset(x: -18, y: 1)
                        }
                    }
                }
            }
        }
        .alert("Reset Comparison List", isPresented: $showResetAlert) {
            Button("Yes", role: .destructive) {
                comparisonItems.removeAll()
                saveComparisonItems(comparisonItems, for: "caffeine")
                selectedOption = newSelectedOption
            }
            Button("No", role: .cancel) {
                isResettingOption = true
                selectedOption = prevSelectedOption
            }
        } message: {
            Text("Switching comparison type will clear the comparison list. Are you sure you want to continue?")
        }
        .alert("\(selectedOption) is Zero", isPresented: $showZeroAlert) {
            Button("Okay", role: .cancel) {
                showZeroAlert = false
            }
            .padding()
        } message: {
            Text("The \(selectedOption) value must be greater than zero for comparison.")
        }

    }
    
    func addToComparison() {
        if(value == 0.0){
            showZeroAlert = true
            return
        } 
        let compVal = caffeine/value
        var unit = ""
        var title = ""
        if (selectedOption == "Price"){
            unit = "g of caffeine per $"
            title = "Most caffeine for the least price"
        } else if (selectedOption == "Sugar") {
            unit = "g of caffeine per g of sugar"
            title = "Most caffeine for the least sugar"
        } else {
            unit = "g of caffeine per cal"
            title = "Most caffeine for the least calories"
        }
        
        let newProduct = Product(name: productName, value: compVal, unit: unit, order: "desc", title: title)
        comparisonItems.append(newProduct)
        saveComparisonItems(comparisonItems,for: "caffeine")
        
        productName = ""
        caffeine = 0.0
        value = 0.0
       
    }
}

struct CaffeineView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            CaffeineView()
        }
    }
}

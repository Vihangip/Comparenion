import SwiftUI


let numberFormatter: NumberFormatter = {
    let formatter = NumberFormatter()
    formatter.numberStyle = .decimal
    formatter.maximumFractionDigits = 2
    return formatter
}()

struct Utilities {
    static func standardizeVal(val: Double, isWeight: Bool, unitToggle: Int) -> Double {
        let lb2g = 453.59
        let oz2g = 28.35
        let oz2ml = 29.57
        var standardizedVal = val
        
        if isWeight {
            switch unitToggle {
            case 1: standardizedVal *= lb2g // lb to g
            case 2: standardizedVal *= oz2g // oz to g
            default: break
            }
        } else {
            switch unitToggle {
            case 1: standardizedVal *= oz2ml // oz to ml
            default: break 
            }
        }
        
        return standardizedVal
    }
}

func saveComparisonItems(_ items: [Product], for viewID: String) {
    if let encoded = try? JSONEncoder().encode(items) {
        UserDefaults.standard.set(encoded, forKey: "comparisonItems_\(viewID)")
    }
}

func loadComparisonItems(for viewID: String) -> [Product] {
    if let data = UserDefaults.standard.data(forKey: "comparisonItems_\(viewID)"),
       let decoded = try? JSONDecoder().decode([Product].self, from: data) {
        return decoded
    }
    return []
}

struct Product: Codable, Identifiable {
    var id = UUID()
    var name: String
    var value: Double
    var unit: String
    var order: String
    var title: String
}

struct InputRow<Content: View>: View {
    let label: String
    let content: () -> Content
    
    var body: some View {
        HStack(alignment: .center)  {
            VStack{
                HStack{
                    Text(label)
                        .frame(width: 200, alignment: .trailing) 
                        .font(.headline)
                        .padding(.trailing, 10)
                    
                }.frame(width: 170, alignment: .trailing)
            }
            VStack{
                HStack{
                    content()
                        .frame(maxWidth: .infinity, alignment: .leading) 
                }.frame(width: 250, alignment: .leading)
                
            }
            
    
        }
        .frame(maxWidth: .infinity)
        
    }
}

func formatValue(_ value: Double) -> String {
    if value == Double(Int(value)) {
        return String(format: "%.0f", value) 
    } else {
        return String(format: "%.2f", value) 
    }
}
